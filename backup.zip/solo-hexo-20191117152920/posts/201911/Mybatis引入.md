title: Mybatis引入
date: '2019-11-11 10:29:59'
updated: '2019-11-11 10:29:59'
tags: [mybatis-plus, springboot]
permalink: /articles/2019/11/11/1573439399177.html
---
![](https://img.hacpai.com/bing/20171230.jpg?imageView2/1/w/960/h/540/interlace/1/q/100)

# Mybatis 在工程引入遇到几个坑，特此记录：

1. mybatisplus 在 maven 中引入后，不可再引入 mybatis 依赖
2.表名不一致时需要在 PO 上面加入@TableName（名称）注解
3. 字段名称不一致时需要加入@TableField(名称) 或者再配置文件中添加配置如下
   ![image.png](https://img.hacpai.com/file/2019/11/image-4561dd3f.png)
4. 确认下namespace中的名称是否正确

完整的配置文件如下：
```
```
server:
  port: 8999
spring:
  datasource:
    driver-class-name: com.mysql.cj.jdbc.Driver
    url: jdbc:mysql://49.233.180.112:3306/wx
    username: root
    password: 13463052930
    filters: stat
    maxActive: 10
    #maxActive: 20
    initialSize: 1
    maxWait: 60000
    minIdle: 1
    timeBetweenEvictionRunsMillis: 60000
    minEvictableIdleTimeMillis: 300000
    validationQuery: select 'x' FROM DUAL #测试数据库连接的SQL
    testWhileIdle: true  #间隔测试以上SQL
    testOnBorrow: false
    testOnReturn: false
    poolPreparedStatements: true
    maxOpenPreparedStatements: 20
  messages:
    encoding: UTF-8
    basename: I18N/messages
mybatis-plus:
  mapperLocations: classpath*:mapper/**/*.xml
  global-config:
   db-column-underline: true
    refresh-mapper: true
    db-config:
      logic-delete-value: 1 # 逻辑已删除值(默认为 1)
      logic-not-delete-value: 0 # 逻辑未删除值(默认为 0)
    banner: false
  configuration:
    map-underscore-to-camel-case: true
    cache-enabled: true #配置的缓存的全局开关
    lazyLoadingEnabled: true #延时加载的开关
    multipleResultSetsEnabled: true #开启的话，延时加载一个属性时会加载该对象全部属性，否则按需加载属性
    log-impl: org.apache.ibatis.logging.stdout.StdOutImpl #打印sql语句,调试用
    jdbc-type-for-null: null
eureka:
  client:
    register-with-eureka: false
    fetch-registry: false
    service-url:
      defaultZone: http://localhost:8761/eureka/
```
```
