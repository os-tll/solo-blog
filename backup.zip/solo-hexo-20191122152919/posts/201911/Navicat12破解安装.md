title: Navicat12 破解安装
date: '2019-11-21 14:00:33'
updated: '2019-11-21 14:09:16'
tags: [数据库]
permalink: /articles/2019/11/21/1574316033946.html
---
链接: https://pan.baidu.com/s/13v1kXkkTcqEuTi7vUbyhLQ 提取码: 7rkg
  
原文链接：https://blog.csdn.net/WYpersist/article/details/86530973

开始安装操作步骤：

第一步安装navicat120_premium_cs_x64这个软件：

第二步破解软件，首先解压文件：

把这个文件夹里面的payload.bin  和version.dll 放到软件安装的目录下即可破解成功。

然后重新打开，成功
