title: C语言之指针变量
date: '2019-11-26 15:07:50'
updated: '2019-11-26 18:03:36'
tags: [C语言]
permalink: /articles/2019/11/26/1574752070512.html
---
### 指针变量：若有一个变量用来存放另一个变量的地址（即指针）
注意区分“指针”与“指针变量”这两个概念。例如，可以说变量i的指针是2000，而不能说i的指针变量是2000。指针是一个地址，而指针变量是存放地址的变量。
### 定义方式
	类型名 *指针变量名
类型名是在定义指针变量时必须指定的“基类型”，用来指定此**指针变量**可以指定的**变量的类型**。
### 赋值方式
地址只可以通过地址符"&"得到并赋给一个指针变量，不可以直接把整数赋给一个指针变量。
### 变量访问方式
间接存储(指针)
```mermaid
graph TB
    subgraph _2000
    var
    end
    subgraph _pointer
    2000-->var
    end
```
直接存储(非指针)
```mermaid
graph TB
    subgraph _pointer
    var
    end
```
### 由小到大输出的两个例子
```
/*由小到大输出,通过交换指针指向,a和b不做交换*/
void exam8_2(){
	int *p1, *p2, *p, a, b;
	scanf("%d,%d", &a, &b);
	p1 = &a;
	p2 = &b;
	if(a < b){
		p = p1;
		p1 = p2;
		p2 = p;
	}
	printf("max %d, min %d\n", *p1, *p2);
}

```
```
/*由小到大输出,通过指针控制a和b交换*/
void exam8_3(){
	void exam8_3_aid(int *p1, int *p2);
	int a, b;
	scanf("%d,%d", &a, &b);
	if(a < b){
	    exam8_3_aid( &a, &b);
	}
	printf("max %d, min %d\n", a, b);
}
void exam8_3_aid(int *p1, int *p2){
	int temp = *p1;
	*p1 =  *p2;
	*p2 = temp;
}
```
### 错误示例
```
/*由小到大输出*、
void exam8_4(){
	void exam8_4_aid(int *p1, int *p2);
	int a, b;
	int *p1, *p2;
	scanf("%d,%d", &a, &b);
	p1 = &a;
	p2 = &b;
	if(a < b){
	    exam8_4_aid(p1, p2);
	}
	printf("max %d, min %d\n", *p1, *p2);
}
void exam8_4_aid(int *p11, int *p12){
	int *temp = p11;
	p11 =  p12;
	p12 = temp;
}
```
内存模拟如下图：
```mermaid
graph TB
    subgraph _2000
     a
    end
    subgraph _2001
     b
    end
    subgraph _p1
     2000-->a  
    end
    subgraph _p2
     2001-->b  
    end
    subgraph _p11
     2000_-->a  
    end
    subgraph _p12
     2001_-->b 
    end
```
