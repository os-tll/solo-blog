title: SpringCloud之配置中心
date: '2019-11-15 20:50:11'
updated: '2019-11-15 20:50:11'
tags: [待分类]
permalink: /articles/2019/11/15/1573822211648.html
---
![](https://img.hacpai.com/bing/20180402.jpg?imageView2/1/w/960/h/540/interlace/1/q/100)



SpringCloud 之   ConfigServer

前言
 
此课程目的是帮助学习者实际在本地搭起一个配置中心，且对原理有一定的了解。

示例地址：https://github.com/os-tll/configdemo/tree/dev
完整PPT：
[springcloudconfigserver.zip](https://img.hacpai.com/file/2019/11/springcloudconfigserver-7c7aaa6e.zip)

入手点

1.What   2.Why    3.How

What's that?

Spring Cloud Config Server其实仅仅是一个带有配置来源属性的SpringBoot应用，其配置源可以是git仓库、SVN仓库或者一个Consul服务。

示例将使用git仓库作为配置源。

Spring Cloud配置中心（Spring Cloud Config）。开发者可以通过Spring Cloud Config Server来统一获取系统配置，并通过Spring Cloud Config Client来消费这些配置信息。

Why is it?

SpringBoot通过properties或者YAML文件为开发者提供了灵活的系统配置方案，我们可以通过多个properties配置为开发环节的各个环境定制不同的系统配置，比如application.properties, application-dev.properties, application-prod.properties等。然而应用一旦启动，要想更新配置，就必须重启应用，新的配置才能生效。

与此同时，在拥有许多服务应用的微服务架构中，开发者们希望可以通过统一管理的方式来管理各个微服务的系统配置。

How to work?

基础

1.创建一个项目用来存放配置文件，存放至GIT中

2.创建配置中心server

3.在client中启用配置中心

4.不重启刷新配置
 
进阶：

1.使用消息中间件（RabbitMQ）自动触发

How to work?

1.创建一个文件夹用来存放配置文件，存放至GIT中

1git创建文件{name}-{profiles}.yml

2.推送Git


2.创建配置中心server

1.创建server工程

2.pom检查

```  
 <dependency>   
    
 <groupId>org.springframework.cloud</groupId>   
    
 <artifactId>spring-cloud-config-server</artifactId>   
    
 </dependency>  
```
3.启动类 @EnableConfigServer


How to work?

4 bootstarp.yml创建

```  
 spring.cloud. config.server.git:   
    
       uri: https://github.com/os-tll/configdemo.git #配置Git仓库的地址  

#      username: #配置git仓库的账号

#      password: #配置git仓库的密码

        search-paths: /configfile #搜索路径

        default-label: dev

        clone-on-start: true #启动时加载配置文件

#开启刷新配置

management. security.enabled: false

 ```

How to work?

3.在client中启用配置中心

1.pom检查
```  
 <dependency>   
    
 <groupId>org.springframework.cloud</groupId>   
    
 <artifactId>spring-cloud-config-client</artifactId>   
    
 </dependency>   
    
<!--监控系统健康-->   
    
 <dependency>   
    
 <groupId>org.springframework.boot</groupId>   
    
 <artifactId>spring-boot-starter-actuator</artifactId>   
    
 </dependency>  
```
      
How to work?

2.bootstrap.yml修改
```  
spring.cloud.config:   
    
 name: configclient #服务名称 ***-dev.yml 中的***   
    
 label: master #配置文件所在master分支   
    
 profile: dev #对应配置文件  ***-dev.yml 中的dev   
    
 discovery:   
    
 enabled: true   
    
 service-id: configserver #配置中心服务名称   
    
#开启刷新配置   
    
management.security. enabled: false  
```
4.@RefreshScope 结合POST请求http://localhost:9001/refresh实现不重启刷新配置

Why is it?

为什么需要进阶？

通过手动POST请求更新SpringBoot应用的而配置虽然方便，但是当微服务系统数目增多的情况下，将带来极大的不便。假设我们的应用部署在10台机器上，当我们调整完某个配置参数时，无需重启机器，10台机器自动能获取到最新的配置。

Why is it?

使用消息中间件（RabbitMQ）自动触发

1、提交配置触发post请求给server端的bus/refresh接口

2、server端接收到请求并发送给Spring Cloud Bus总线

3、Spring Cloud bus接到消息并通知给其它连接到总线的客户端

4、其它客户端接收到通知，请求Server端获取最新配置

5、全部客户端均获取到最新的配置


How to work?

   1.rabbitmq 安装

3.config server 和 client的bootstrap.yml修改
```  
spring：   
    
 rabbitmq:   
    
 host: localhost   
    
 port: 7672   
    
 username: guest   
    
 password: guest   
    
#开启刷新配置   
    
management. security.enabled: false  
```

2.config server 和 config client的mvn 添加
```  
    
<!-- springcloud-bus依赖实现配置自动更新，rabbitmq -->   
    
<dependency>   
    
 <groupId>org.springframework.cloud</groupId>   
    
 <artifactId>   
    
spring-cloud-starter-bus-amqp   
    
 </artifactId>   
    
</dependency>  
```
How to work?

4.使用Post方式请求config-service 的/bus/refresh，刷新总线



