title: C语言之指针是什么
date: '2019-11-26 15:07:50'
updated: '2019-11-26 15:08:57'
tags: [C语言]
permalink: /articles/2019/11/26/1574752070512.html
---
### 指针变量：若有一个变量用来存放另一个变量的地址（即指针）
注意区分“指针”与“指针变量”这两个概念。例如，可以说变量i的指针是2000，而不能说i的指针变量是2000。指针是一个地址，而指针变量是存放地址的变量。
### 变量访问方式
间接存储(指针)
```mermaid
graph TB
    subgraph _2000
    var
    end
    subgraph _pointer
    2000-->var
    end
```
直接存储(非指针)
```mermaid
graph TB
    subgraph _pointer
    var
    end
```
